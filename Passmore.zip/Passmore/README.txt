Luke Austin La'akea Passmore
lpassmore3@gatech.edu
Java Version: Java 1.8.0_101

*Note when testing the application:
    - When using the different ink tools, they may not
      respond correctly at the very beginning. This is
      because my web browser starts at en.wikipedia.org
      and it takes a while for it to load. Just give it a
      couple seconds.

    - When creating a sticky note, once the mouse is released
      you can begin typing. To end typing, either press ENTER
      or click outside of the sticky note. Typing will also
      end if the text were to go past the length of the note.

List of extra features:
    - My status bar specifies the current page number and
      the total page number.
    - Create a drop shadow for the sticky notes.
    - Created different ink colors for free-form ink,
      rectangle, and oval as well as corresponding
      radio buttons.
    - Implemented backspacing when initially typing in
      a sticky note.